<template>
  <div>
      <h1 class="vue">I am Vue js application for Micro frontend</h1>
  </div>
</template>