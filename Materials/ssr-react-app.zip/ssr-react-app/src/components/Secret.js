import React from "react";

const Secret = () => (
    <div className="wrapper">
        <h2>This is the secret page</h2>
    </div>
);

export default Secret;
