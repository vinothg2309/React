import React from "react";

const About = () => (
    <div className="wrapper">
        <h2>This is the about page</h2>
    </div>
);

export default About;
